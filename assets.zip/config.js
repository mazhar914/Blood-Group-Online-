// config.js - Rajowal Health Services Configuration
const APP_CONFIG = {
    // فائر بیس کی مکمل کنفیگریشن
    firebaseConfig: {
        apiKey: "AIzaSyBlKed_0bGlH9SIibNE6kcoUkjeCCtqefA",
        authDomain: "bloodgrouprajowal.firebaseapp.com",
        projectId: "bloodgrouprajowal",
        storageBucket: "bloodgrouprajowal.firebasestorage.app",
        messagingSenderId: "559548914291",
        appId: "1:559548914291:web:b402c07576d69b6c416806"
    },
    // ایڈمن کا موبائل نمبر
    adminPhone: "+923346002440"
};

// 1. فائر بیس کو انیشلائز کرنا
if (typeof firebase !== 'undefined') {
    firebase.initializeApp(APP_CONFIG.firebaseConfig);
    console.log("Firebase initialized.");
}

// 2. سروس ورکر کی رجسٹریشن اور اپڈیٹ ہینڈلر
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
            .then(registration => {
                console.log('Service Worker registered successfully');

                // نئی اپڈیٹ چیک کرنا
                registration.onupdatefound = () => {
                    const installingWorker = registration.installing;
                    installingWorker.onstatechange = () => {
                        if (installingWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            // جب نئی اپڈیٹ ڈاؤن لوڈ ہو جائے تو پاپ اپ دکھائیں
                            showUpdateUI(installingWorker);
                        }
                    };
                };
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    });
}

// اپڈیٹ پاپ اپ دکھانے کا فنکشن
function showUpdateUI(worker) {
    const updateBar = document.createElement('div');
    updateBar.id = 'update-notification';
    updateBar.style.cssText = `
        position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
        background: #333; color: white; padding: 15px 25px; border-radius: 50px;
        z-index: 10000; display: flex; align-items: center; gap: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5); font-family: sans-serif;
        width: 90%; max-width: 400px; justify-content: space-between;
    `;
    
    updateBar.innerHTML = `
        <span style="font-size:14px;">نئی اپڈیٹ دستیاب ہے!</span>
        <button id="refresh-now" style="background:#25D366; border:none; color:white; padding:8px 16px; border-radius:20px; cursor:pointer; font-weight:bold;">اپڈیٹ کریں</button>
    `;
    
    document.body.appendChild(updateBar);

    document.getElementById('refresh-now').onclick = () => {
        // سروس ورکر کو بتانا کہ نئے ورژن پر سوئچ کرے
        worker.postMessage({ action: 'skipWaiting' });
        updateBar.remove();
        window.location.reload(); // صفحہ ریفریش کریں
    };
}
