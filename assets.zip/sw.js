// کیشے کا نام (جب بھی فائلیں بدلیں تو v1 کو v2، پھر v3 کر دیا کریں)
const CACHE_NAME = 'rajowal-health-v1';

// ان تمام فائلوں کی لسٹ جنہیں آف لائن چلانا ہے
const ASSETS_TO_CACHE = [
    './',
    './index.html',
    './blood-bank.html',
    './doctor.html',
    './Hospital.html',
    './lab.html',
    './managehospital.html',
    './managelab.html',
    './managestore.html',
    './medical-store.html',
    './config.js',
    './data.json'
];

// 1. انسٹالیشن ایونٹ: فائلوں کو فون میں محفوظ کرنا
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            console.log('سروس ورکر: فائلیں کیشے ہو رہی ہیں');
            return cache.addAll(ASSETS_TO_CACHE);
        })
    );
});

// 2. ایکٹیویشن ایونٹ: پرانے کیشے کو صاف کرنا
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cache) => {
                    if (cache !== CACHE_NAME) {
                        console.log('سروس ورکر: پرانا کیشے ختم کیا جا رہا ہے');
                        return caches.delete(cache);
                    }
                })
            );
        })
    );
});

// 3. فیچ ایونٹ: جب انٹرنیٹ نہ ہو تو کیشے سے فائل دکھانا
self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((cachedResponse) => {
            return cachedResponse || fetch(event.request);
        })
    );
});

// 4. میسج سننے کا ایونٹ (پاپ اپ بٹن کے لیے)
// یہ نئے سروس ورکر کو "Waiting" سٹیٹ سے نکال کر فوری ایکٹیویٹ کرتا ہے
self.addEventListener('message', (event) => {
    if (event.data && event.data.action === 'skipWaiting') {
        self.skipWaiting();
    }
});
